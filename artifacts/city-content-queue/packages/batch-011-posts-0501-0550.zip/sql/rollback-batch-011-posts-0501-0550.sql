-- Rollback SQL for this 50-post package
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_520_ci;
SET collation_connection = 'utf8mb4_unicode_520_ci';
USE `navaraby_wp569`;

-- rollback: 1160008002028-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1160008002028-tape20' WHERE p.post_name='دلگشا-ایلام-navar-tip-20cm' AND p.post_type='ilam' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1170009002477-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1170009002477-tape20' WHERE p.post_name='مارگون-کهگیلویه-و-بویراحمد-navar-tip-20cm' AND p.post_type='kohgiluyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1170006002828-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1170006002828-tape20' WHERE p.post_name='سرفاریاب-کهگیلویه-و-بویراحمد-navar-tip-20cm' AND p.post_type='kohgiluyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1170003001515-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1170003001515-tape20' WHERE p.post_name='دوگنبدان-کهگیلویه-و-بویراحمد-navar-tip-20cm' AND p.post_type='kohgiluyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1170008002129-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1170008002129-tape20' WHERE p.post_name='لنده-کهگیلویه-و-بویراحمد-navar-tip-20cm' AND p.post_type='kohgiluyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1170002001514-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1170002001514-tape20' WHERE p.post_name='دهدشت-کهگیلویه-و-بویراحمد-navar-tip-20cm' AND p.post_type='kohgiluyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1180001002481-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1180001002481-tape20' WHERE p.post_name='چغادک-بوشهر-navar-tip-20cm' AND p.post_type='bushehr' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1170002002480-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1170002002480-tape20' WHERE p.post_name='دیشموک-کهگیلویه-و-بویراحمد-navar-tip-20cm' AND p.post_type='kohgiluyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1060002002803-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1060002002803-tape20' WHERE p.post_name='بیدروبه-خوزستان-navar-tip-20cm' AND p.post_type='ahvaz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1180003002369-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1180003002369-tape20' WHERE p.post_name='دالکی-بوشهر-navar-tip-20cm' AND p.post_type='bushehr' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1180003002482-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1180003002482-tape20' WHERE p.post_name='وحدتیه-بوشهر-navar-tip-20cm' AND p.post_type='bushehr' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1180009002087-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1180009002087-tape20' WHERE p.post_name='انارستان-بوشهر-navar-tip-20cm' AND p.post_type='bushehr' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1180004001521-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1180004001521-tape20' WHERE p.post_name='خورموج-بوشهر-navar-tip-20cm' AND p.post_type='bushehr' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1180006002661-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1180006002661-tape20' WHERE p.post_name='سیراف-بوشهر-navar-tip-20cm' AND p.post_type='bushehr' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1200001001540-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1200001001540-tape20' WHERE p.post_name='دامغان-سمنان-navar-tip-20cm' AND p.post_type='semnan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1190001001531-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1190001001531-tape20' WHERE p.post_name='هیدج-زنجان-navar-tip-20cm' AND p.post_type='zanjan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1190003002833-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1190003002833-tape20' WHERE p.post_name='نوربهار-زنجان-navar-tip-20cm' AND p.post_type='zanjan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1190003002260-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1190003002260-tape20' WHERE p.post_name='گرماب-زنجان-navar-tip-20cm' AND p.post_type='zanjan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1200003002775-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1200003002775-tape20' WHERE p.post_name='رودیان-سمنان-navar-tip-20cm' AND p.post_type='semnan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1200007002162-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1200007002162-tape20' WHERE p.post_name='میامی-سمنان-navar-tip-20cm' AND p.post_type='semnan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10600026002920-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10600026002920-layflat' WHERE p.post_name='جولکی-خوزستان-looleh-nakhi-tashoo' AND p.post_type='ahvaz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1060007002312-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1060007002312-tape20' WHERE p.post_name='مینوشهر-خوزستان-navar-tip-20cm' AND p.post_type='ahvaz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1210006002024-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1210006002024-tape20' WHERE p.post_name='بفروییه-یزد-navar-tip-20cm' AND p.post_type='yazd' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12100013001561-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12100013001561-tape20' WHERE p.post_name='زارچ-یزد-navar-tip-20cm' AND p.post_type='yazd' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1060008002967-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1060008002967-tape20' WHERE p.post_name='منتظران-خوزستان-navar-tip-20cm' AND p.post_type='ahvaz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12200012002724-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12200012002724-tape20' WHERE p.post_name='گروک-هرمزگان-navar-tip-20cm' AND p.post_type='bandarabbas' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12200010001564-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12200010001564-tape20' WHERE p.post_name='خمیر-هرمزگان-navar-tip-20cm' AND p.post_type='bandarabbas' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1230003002270-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1230003002270-tape20' WHERE p.post_name='باقرشهر-تهران-navar-tip-20cm' AND p.post_type='tehran' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12300019002278-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12300019002278-tape20' WHERE p.post_name='گلستان-تهران-navar-tip-20cm' AND p.post_type='tehran' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12300014002634-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12300014002634-tape20' WHERE p.post_name='ارجمند-تهران-navar-tip-20cm' AND p.post_type='tehran' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1230009002632-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1230009002632-tape20' WHERE p.post_name='باغستان-تهران-navar-tip-20cm' AND p.post_type='tehran' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12300014001577-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12300014001577-tape20' WHERE p.post_name='فیروزکوه-تهران-navar-tip-20cm' AND p.post_type='tehran' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12300016002116-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12300016002116-tape20' WHERE p.post_name='قدس-تهران-navar-tip-20cm' AND p.post_type='tehran' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1240003002164-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1240003002164-tape20' WHERE p.post_name='هشتجین-اردبیل-navar-tip-20cm' AND p.post_type='ardabil' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12400012001065-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12400012001065-tape20' WHERE p.post_name='زیوه-اردبیل-navar-tip-20cm' AND p.post_type='ardabil' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 12700010001182-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='12700010001182-tape20' WHERE p.post_name='آزادشهر-گلستان-navar-tip-20cm' AND p.post_type='golestan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1270005001181-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1270005001181-tape20' WHERE p.post_name='گرگان-گلستان-navar-tip-20cm' AND p.post_type='golestan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1280004001038-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1280004001038-tape20' WHERE p.post_name='خانلق-خراسان-شمالی-navar-tip-20cm' AND p.post_type='north_khorasan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1280005002079-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1280005002079-tape20' WHERE p.post_name='تیتکانلو-خراسان-شمالی-navar-tip-20cm' AND p.post_type='north_khorasan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1290001001355-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1290001001355-tape20' WHERE p.post_name='بیرجند-خراسان-جنوبی-navar-tip-20cm' AND p.post_type='south_khorasan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1290007001002-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1290007001002-tape20' WHERE p.post_name='باغستان-خراسان-جنوبی-navar-tip-20cm' AND p.post_type='south_khorasan' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1050005001265-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1050005001265-tape20' WHERE p.post_name='سنقر-کرمانشاه-navar-tip-20cm' AND p.post_type='kermanshah' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10500010002414-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10500010002414-layflat' WHERE p.post_name='دینور-کرمانشاه-looleh-nakhi-tashoo' AND p.post_type='kermanshah' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10600021002928-tape20
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10600021002928-tape20' WHERE p.post_name='زاووت-خوزستان-navar-tip-20cm' AND p.post_type='ahvaz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10700021002820-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10700021002820-layflat' WHERE p.post_name='خوزی-فارس-looleh-nakhi-tashoo' AND p.post_type='shiraz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10700012002555-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10700012002555-layflat' WHERE p.post_name='کامفیروز-فارس-looleh-nakhi-tashoo' AND p.post_type='shiraz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10700028001042-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10700028001042-layflat' WHERE p.post_name='اکبرآباد-فارس-looleh-nakhi-tashoo' AND p.post_type='shiraz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 10700012002951-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='10700012002951-layflat' WHERE p.post_name='فاروق-فارس-looleh-nakhi-tashoo' AND p.post_type='shiraz' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1040002001236-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1040002001236-layflat' WHERE p.post_name='پیرانشهر-آذربایجان-غربی-looleh-nakhi-tashoo' AND p.post_type='orumiyeh' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;


-- rollback: 1080005002201-layflat
SET NAMES utf8mb4;
USE `navaraby_wp569`;
START TRANSACTION;
SET @rollback_post_id=(SELECT p.ID FROM `ha_posts` p JOIN `ha_postmeta` marker ON marker.post_id=p.ID AND marker.meta_key='_navar_city_queue_generated' AND marker.meta_value='1080005002201-layflat' WHERE p.post_name='خانوک-کرمان-looleh-nakhi-tashoo' AND p.post_type='kerman' LIMIT 1);
DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` a ON a.ID=pm.post_id WHERE a.post_parent=@rollback_post_id AND a.post_type='attachment';
DELETE FROM `ha_posts` WHERE post_parent=@rollback_post_id AND post_type='attachment';
DELETE FROM `ha_postmeta` WHERE post_id=@rollback_post_id;
DELETE FROM `ha_posts` WHERE ID=@rollback_post_id;
COMMIT;

