-- Rollback SQL for this 50-post package

-- rollback: 10200014001193-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='رویان-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='رویان-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='رویان-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='رویان-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014001189-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نور-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نور-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='نور-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='نور-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014001189-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نور-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نور-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='نور-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='نور-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014002119-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چمستان-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چمستان-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='چمستان-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='چمستان-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014002119-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چمستان-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چمستان-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='چمستان-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='چمستان-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200015001194-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نوشهر-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نوشهر-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='نوشهر-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='نوشهر-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200015001194-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نوشهر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='نوشهر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='نوشهر-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='نوشهر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200015002779-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کجور-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کجور-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کجور-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کجور-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200015002779-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کجور-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کجور-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کجور-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کجور-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200020002748-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='هچیرود-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='هچیرود-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='هچیرود-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='هچیرود-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200020002748-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='هچیرود-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='هچیرود-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='هچیرود-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='هچیرود-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200020001190-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چالوس-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چالوس-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='چالوس-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='چالوس-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200020001190-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چالوس-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='چالوس-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='چالوس-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='چالوس-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200028001191-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلاردشت-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلاردشت-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کلاردشت-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کلاردشت-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200028001191-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلاردشت-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلاردشت-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کلاردشت-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کلاردشت-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10300021001201-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آذرشهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آذرشهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='آذرشهر-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='آذرشهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300021001201-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آذرشهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آذرشهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='آذرشهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='آذرشهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300021002763-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تیمورلو-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تیمورلو-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='تیمورلو-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='تیمورلو-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300021002763-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تیمورلو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تیمورلو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='تیمورلو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='تیمورلو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300021001203-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ممقان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ممقان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ممقان-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='ممقان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300021001203-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ممقان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ممقان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ممقان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='ممقان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300021001202-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='گوگان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='گوگان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='گوگان-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='گوگان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300021001202-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='گوگان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='گوگان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='گوگان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='گوگان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300022001204-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسکو-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسکو-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اسکو-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='اسکو-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300022001204-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسکو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسکو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اسکو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='اسکو-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300022001205-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایلخچی-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایلخچی-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ایلخچی-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='ایلخچی-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300022001205-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایلخچی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایلخچی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ایلخچی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='ایلخچی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300022002033-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سهند-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سهند-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سهند-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='سهند-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300022002033-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سهند-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سهند-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سهند-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='سهند-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030002001200-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اهر-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='اهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030002001200-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='اهر-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300013001025-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کردکندی-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کردکندی-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کردکندی-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='کردکندی-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300013001025-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کردکندی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کردکندی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کردکندی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='کردکندی-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300012001221-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بناب-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بناب-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='بناب-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='بناب-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300012001221-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بناب-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بناب-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='بناب-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='بناب-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030003001067-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسفهلان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسفهلان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اسفهلان-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='اسفهلان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030003001067-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسفهلان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اسفهلان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اسفهلان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='اسفهلان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030003001213-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='باسمنج-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='باسمنج-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='باسمنج-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='باسمنج-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030003001213-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='باسمنج-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='باسمنج-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='باسمنج-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='باسمنج-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030003001214-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تبریز-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تبریز-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='تبریز-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='تبریز-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030003001214-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تبریز-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='تبریز-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='تبریز-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='تبریز-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030003001206-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='خسروشاه-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='خسروشاه-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='خسروشاه-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='خسروشاه-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030003001206-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='خسروشاه-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='خسروشاه-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='خسروشاه-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='خسروشاه-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030003001215-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سردرود-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سردرود-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سردرود-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='سردرود-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030003001215-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سردرود-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سردرود-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سردرود-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='سردرود-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 1030003001068-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='لاهیجان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='لاهیجان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='لاهیجان-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='لاهیجان-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 1030003001068-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='لاهیجان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='لاهیجان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='لاهیجان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='لاهیجان-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300019001225-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='جلفا-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='جلفا-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='جلفا-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='جلفا-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;


-- rollback: 10300019001225-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='جلفا-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='جلفا-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='جلفا-آذربایجان-شرقی-looleh-nakhi-tashoo' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='جلفا-آذربایجان-شرقی-looleh-nakhi-tashoo' AND post_type='post'; COMMIT;


-- rollback: 10300019001226-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='هادیشهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='هادیشهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='هادیشهر-آذربایجان-شرقی-navar-tip-20cm' AND p.post_type='post'; DELETE FROM `ha_posts` WHERE post_name='هادیشهر-آذربایجان-شرقی-navar-tip-20cm' AND post_type='post'; COMMIT;

